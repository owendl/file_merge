# Executable instructions

This folder contains an executable (wrapper_script.exe) that will attempt to match tracks from cue sheets to music vendor libraries. This is a compiled version of some python code available [here](https://github.com/owendl/file_merge). It will first attempt to find perfect file name matches, if a perfect match is not available then it will attempt to find a close match and write all of these results to a new file.

## Folder Structure
It requires a particular folder structure to operate:

```
windows_exe
|	README.md
|	wrapper_script.exe
|	...
|
|---data
	|---vendor_files
	|	|	(vendor sheet files)
	|	|	...
	|
	|---cue_sheets
		|	(cue sheets)
		|	...

```

## Vendor Files

The first time running the executable it will attempt to consolidate all of the vendor files into a single consistent format then write that to a local file for future use (note: if someone gives you an already consolidated file of the vendors, just place it in the `vendor_files` folder and this consolidation step will be skipped). 

The executable has custom parsing functions for each vendor type. The currently configured vendor file types are:
* STKA
* FTM
* AA
* SignatureTracks
* DMS

For any vendor file to be consolidated, it must be an excel file and its name must begin with one of the file type strings indicated above. For example `STKA_CLIENT_ThruADD86.xlsx`.

## Cue Sheets
Cue sheets should have all header rows removed. The first row of the file should be the column names: 

CHANNEL | EVENT | CLIP NAME | START TIME | END TIME | DURATION      

followed by all of the clips.

## Executing the executable
There are two ways to run the code: 
1* double-click on the wrapper_script.exe file- This will open a console window and status updates will print to the window. When the process is done, a file of matches will be written to the data folder. If the console window has closed and no matches file has been written, that means the code hit an error along the way. To learn what the error was, you can proceed to the second option to run the code.
2* run exe from command prompt- open a windows command prompt and change directory to the windows_exe folder (`cd path/to/windows_exe`). Once in the folder you can run the executable with `wrapper_script.exe`. This will run the code in this window and keep it open even if an error occurs.